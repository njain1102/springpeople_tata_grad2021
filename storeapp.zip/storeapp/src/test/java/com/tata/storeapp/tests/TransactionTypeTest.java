package com.tata.storeapp.tests;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import java.util.EnumSet;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class TransactionTypeTest {
    @ParameterizedTest
    @EnumSource(value = com.tata.storeapp.models.TransactionType.class, names = { "CARD", "WALLET","UPI" })
    void testWithEnumSourceTransactionTypeInclude(com.tata.storeapp.models.TransactionType transactionType) {
        assertTrue(EnumSet.of(com.tata.storeapp.models.TransactionType.CARD, com.tata.storeapp.models.TransactionType.WALLET, com.tata.storeapp.models.TransactionType.UPI).
                contains(transactionType));
    }
}
