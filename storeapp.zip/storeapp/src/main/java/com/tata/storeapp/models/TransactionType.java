package com.tata.storeapp.models;

public enum TransactionType {
    CARD,WALLET,UPI,NETBANKING
}
