package com.shoppersden.dao.interfaces;

import com.shoppersden.models.Cart;
import com.shoppersden.models.User;

import java.sql.SQLException;

public interface CartDao {
    public void addCart(User user) throws SQLException;
    public Cart getCartByUser(User user) throws SQLException;
    public Cart getCartById(int cartId) throws SQLException;

}
