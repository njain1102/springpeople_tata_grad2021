package com.shoppersden.dao.interfaces;

import com.shoppersden.models.CartProducts;
import com.shoppersden.models.User;

import java.sql.SQLException;
import java.util.List;

public interface CartProductsDao {
    public void addProductInCart(User user, int productId, int quantity) throws SQLException;
    public List<CartProducts> getAllProductInCart(User user) throws SQLException;
    public void emptyUserCart(User user) throws SQLException;

    //remaining
    // public void deleteProductInCart(User user, int productId) throws SQLException;



}
