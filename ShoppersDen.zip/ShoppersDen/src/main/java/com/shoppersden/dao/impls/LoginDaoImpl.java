package com.shoppersden.dao.impls;

import com.shoppersden.dao.interfaces.LoginDao;
import com.shoppersden.helpers.PostgresConnHelper;

import java.sql.*;
import java.util.ResourceBundle;

public class LoginDaoImpl implements LoginDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement passwordverify, adminverify;
    private Statement statement;
    private ResultSet resultSet;

    public LoginDaoImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection not estd!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public boolean passwordVerfication(int id, String pass) throws SQLException {
        String query = resourceBundle.getString("validatepassword");
        passwordverify = conn.prepareStatement(query);
        passwordverify.setInt(1,id);
        resultSet = passwordverify.executeQuery();
        if (resultSet.next()){
            return true;
        }
        return false;
    }

    @Override
    public boolean adminVerfication(int id) throws SQLException {
        String query = resourceBundle.getString("validateadmin");
        adminverify = conn.prepareStatement(query);
        adminverify.setInt(1,id);
        resultSet = adminverify.executeQuery();
        if(resultSet.next()){
           return true;
        }
        return false;
    }
}
