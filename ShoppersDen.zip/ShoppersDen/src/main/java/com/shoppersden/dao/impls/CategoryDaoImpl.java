package com.shoppersden.dao.impls;

import com.shoppersden.dao.interfaces.CategoryDao;
import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.Category;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CategoryDaoImpl implements CategoryDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private Statement statement;
    private PreparedStatement addcategory,getbyid;
    private ResultSet resultSet;

    public CategoryDaoImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection not estd!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addCategory(Category category) throws SQLException {
        String addCategory = resourceBundle.getString("addcategory");
        addcategory = conn.prepareStatement(addCategory);
        addcategory.setInt(1, category.getCid());
        addcategory.setString(2, category.getCname());
        addcategory.executeUpdate();
    }

    @Override
    public List<Category> getAllCategories() throws SQLException {
        String query=resourceBundle.getString("selectallcategory");;
        List<Category> categoryList=new ArrayList<Category>();
        Category category=null;
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()){
            category=new Category();
            category.setCid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));
            categoryList.add(category);
        }
        return categoryList;
    }

    @Override
    public Category getCategoryById(int categoryId) throws SQLException {
        Category category = null;
        String query = resourceBundle.getString("selectcategorybyid");
        getbyid = conn.prepareStatement(query);
        getbyid.setInt(1,categoryId);
        resultSet=getbyid.executeQuery();
        while(resultSet.next()) {
            category = new Category();
            category.setCid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));
        }
        return category;
    }


}
