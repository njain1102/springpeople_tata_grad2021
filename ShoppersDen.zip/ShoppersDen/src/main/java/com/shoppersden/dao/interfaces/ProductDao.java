package com.shoppersden.dao.interfaces;

import com.shoppersden.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface ProductDao {
    List<Product> getAllProducts() throws SQLException;
    public Product getProductById(int pid) throws SQLException;
    public void addProduct(Product product) throws SQLException;
    public void updateProductName(int pid,String pname) throws SQLException;

}
