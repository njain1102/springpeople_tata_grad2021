package com.shoppersden.dao.impls;

import com.shoppersden.dao.interfaces.CartDao;
import com.shoppersden.dao.interfaces.CartProductsDao;
import com.shoppersden.dao.interfaces.OrderDao;
import com.shoppersden.dao.interfaces.UserDao;
import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.Order;
import com.shoppersden.models.PaymentMode;
import com.shoppersden.models.User;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class OrderDaoImpl implements OrderDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private Statement statement;
    private PreparedStatement placeorder,confirmorder,viewallorder,getorderbyid;
    private ResultSet resultSet;

    public OrderDaoImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection not estd!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void placeOrder(User user, Order order) throws SQLException {
        String addorder=resourceBundle.getString("addorder");
        placeorder=conn.prepareStatement(addorder);
        placeorder.setInt(1,order.getOrderId());
        placeorder.setDate(2, Date.valueOf(order.getDatePlaced()));
        placeorder.setInt(3,order.getCart().getCartId());
        placeorder.setInt(4,user.getUserId());
        placeorder.setInt(5,order.getAmount());
        placeorder.setBoolean(6,order.isPaid());
        placeorder.executeUpdate();
    }

    @Override
    public void confirmOrder(User user, int OrderId, String mode) throws SQLException {
        String confirmOrder = resourceBundle.getString("confirmorder");
        confirmorder = conn.prepareStatement(confirmOrder);
        confirmorder.setDate(1,Date.valueOf(LocalDate.now().plus(2+new Random().nextInt(5), ChronoUnit.DAYS)));
        confirmorder.setString(2,mode);
        confirmorder.setBoolean(3,true);
        confirmorder.setInt(4, OrderId);
        confirmorder.executeUpdate();

        CartProductsDao cartProductsDao = new CartProductsDaoImpl();
        cartProductsDao.emptyUserCart(user);
    }

    @Override
    public List<Order> viewAllOrder(int userId) throws SQLException {
        Order order = null;
        String paymentMode = null;
        CartDao cartDao = new CartDaoImpl();
        UserDao userDao = new UserDaoImpl();
        List<Order> orderList = new ArrayList<Order>();
        String query = resourceBundle.getString("selectallorderbyuid");
        viewallorder = conn.prepareStatement(query);
        viewallorder.setInt(1,userId);
        resultSet = viewallorder.executeQuery();
        while(resultSet.next()){
            order = new Order();
            order.setOrderId(resultSet.getInt(1));
            order.setDatePlaced(resultSet.getDate(2).toLocalDate());
            order.setCart(cartDao.getCartById(resultSet.getInt(3)));
            order.setUser(userDao.getUserById(resultSet.getInt(4)));
            order.setDateDelivered(resultSet.getDate(5).toLocalDate());
            order.setAmount(resultSet.getInt(6));
            paymentMode = resultSet.getString(7);
            if(paymentMode.equals("Debit")) {
                order.setPaymentMode(PaymentMode.DEBIT);
            } else {
                order.setPaymentMode(PaymentMode.UPI);
            }
            order.setPaid(resultSet.getBoolean(8));
            orderList.add(order);
        }
        return orderList;
    }

    @Override
    public Order getOrderById(int orderId) throws SQLException {
        Order order=null;
        String paymentMode = null;
        CartDao cartDao = new CartDaoImpl();
        UserDao userDao = new UserDaoImpl();
        String query = resourceBundle.getString("selectorderbyid");
        getorderbyid = conn.prepareStatement(query);
        getorderbyid.setInt(1,orderId);
        resultSet = getorderbyid.executeQuery();
        while(resultSet.next()) {
            order=new Order();
            order.setOrderId(resultSet.getInt(1));
            order.setDatePlaced(resultSet.getDate(2).toLocalDate());
            order.setCart(cartDao.getCartById(resultSet.getInt(3)));
            order.setUser(userDao.getUserById(resultSet.getInt(4)));
            if(resultSet.getDate(5)!=null)
                order.setDateDelivered(resultSet.getDate(5).toLocalDate());
            order.setAmount(resultSet.getInt(6));
            paymentMode = resultSet.getString(7);
            if(paymentMode.equals("Debit")) {
                order.setPaymentMode(PaymentMode.DEBIT);
            } else {
                order.setPaymentMode(PaymentMode.UPI);
            }
            order.setPaid(resultSet.getBoolean(8));
        }
        return order;
    }
}
