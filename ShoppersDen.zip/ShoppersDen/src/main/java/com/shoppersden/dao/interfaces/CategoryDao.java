package com.shoppersden.dao.interfaces;

import com.shoppersden.models.Category;

import java.sql.SQLException;
import java.util.List;

public interface CategoryDao {
    void addCategory(Category category) throws SQLException;
    List<Category> getAllCategories() throws SQLException;
    Category getCategoryById(int categoryId) throws SQLException;

    /* remaining
    void updateCategory(int cid,String catname) throws SQLException;
    public void deleteCategory(int cid) throws SQLException;

     */
}
