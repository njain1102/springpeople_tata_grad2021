package com.shoppersden.dao.impls;

import com.shoppersden.dao.interfaces.CartDao;
import com.shoppersden.dao.interfaces.UserDao;
import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.Cart;
import com.shoppersden.models.User;

import java.sql.*;
import java.util.ResourceBundle;

public class CartDaoImpl implements CartDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private Statement statement;
    private PreparedStatement addtocart,getcartbyuser,getcartbyid;
    private ResultSet resultSet;

    public CartDaoImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection not estd!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }


    @Override
    public void addCart(User user) throws SQLException {
        String addcartquery=resourceBundle.getString("addcart");
        addtocart = conn.prepareStatement(addcartquery);
        addtocart.setInt(1,user.getCart().getCartId());
        addtocart.setInt(2,user.getUserId());
        addtocart.executeUpdate();
    }

    @Override
    public Cart getCartByUser(User user) throws SQLException {
        int uid = user.getUserId();
        String byuserquery = resourceBundle.getString("selectcartbyuid");
        getcartbyuser=conn.prepareStatement(byuserquery);
        getcartbyuser.setInt(1,uid);
        resultSet=getcartbyuser.executeQuery();
        Cart cart = new Cart();
        while (resultSet.next()) {
            cart.setCartId(resultSet.getInt(1));
            cart.setUser(user);
        }
        return cart;
    }

    @Override
    public Cart getCartById(int cartId) throws SQLException {
        Cart cart = null;
        UserDao userDao = new UserDaoImpl();
        String byidquery = resourceBundle.getString("selectcartbycartid");
        getcartbyid=conn.prepareStatement(byidquery);
        getcartbyid.setInt(1,cartId);
        resultSet=getcartbyid.executeQuery();
        while (resultSet.next()) {
            cart = new Cart();
            cart.setCartId(resultSet.getInt(1));
            cart.setUser(userDao.getUserById(resultSet.getInt(2)));
        }
        return cart;
    }


}
