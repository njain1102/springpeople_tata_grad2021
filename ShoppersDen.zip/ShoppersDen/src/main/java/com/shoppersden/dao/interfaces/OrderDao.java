package com.shoppersden.dao.interfaces;

import com.shoppersden.models.Order;
import com.shoppersden.models.User;

import java.sql.SQLException;
import java.util.List;

public interface OrderDao {
    void placeOrder(User user, Order order) throws SQLException;
    void confirmOrder(User user, int orderId, String mode) throws SQLException;
    List<Order> viewAllOrder(int userId) throws SQLException;
    Order getOrderById(int orderId) throws SQLException;
}
