package com.shoppersden.dao.interfaces;

import java.sql.SQLException;

public interface LoginDao {

    public boolean passwordVerfication(int id, String pass) throws SQLException;
    public boolean adminVerfication(int id) throws SQLException;
}
