package com.shoppersden.dao.impls;

import com.shoppersden.dao.interfaces.CartDao;
import com.shoppersden.dao.interfaces.UserDao;
import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.User;
import com.shoppersden.models.UserMode;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class UserDaoImpl implements UserDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private Statement statement;
    private PreparedStatement addtheuser,updateuser,getuserbyid;
    private ResultSet resultSet, resultSet2;

    public UserDaoImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection not estd!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public List<User> getAllUsers() throws SQLException {
        List<User>userList=new ArrayList<User>();
        User user = null;
        String query = resourceBundle.getString("selectalluser");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()) {
            user = new User();
            user.setUserId(resultSet.getInt(1));
            user.setUserName(resultSet.getString(2));
            user.setEmail(resultSet.getString(3));
            user.setPassword(resultSet.getString(4));
            user.setSecQue(resultSet.getString(5));
            user.setAnswer(resultSet.getString(6));
            user.setAddress(resultSet.getString(7));
            user.setPhone(resultSet.getLong(8));
            if(resultSet.getInt(9)==1) {
                user.setUserMode(UserMode.ADMIN);
            } else {
                user.setUserMode(UserMode.CUSTOMER);
            }

            CartDao cartDao = new CartDaoImpl();
            user.setCart(cartDao.getCartByUser(user));
            userList.add(user);
        }
        return userList;
    }

    @Override
    public void addUser(User user) throws SQLException {
        String adduser=resourceBundle.getString("adduser");
        addtheuser=conn.prepareStatement(adduser);
        addtheuser.setInt(1,user.getUserId());
        addtheuser.setString(2,user.getUserName());
        addtheuser.setString(3,user.getEmail());
        addtheuser.setString(4,user.getPassword());
        addtheuser.setString(5,user.getSecQue());
        addtheuser.setString(6,user.getAnswer());
        addtheuser.setString(7,user.getAddress());
        addtheuser.setLong(8,user.getPhone());
        if(user.getUserMode().equals(UserMode.ADMIN)) {
            addtheuser.setInt(9,1);
        } else {
            addtheuser.setInt(9,2);
        }
        addtheuser.executeUpdate();
        CartDao cartDao = new CartDaoImpl();
        cartDao.addCart(user);
    }

    @Override
    public void updateUserName(int userId, String name) throws SQLException {
        String query = resourceBundle.getString("updateusername");
        updateuser = conn.prepareStatement(query);
        updateuser.setString(1,name);
        updateuser.setInt(2,userId);
        updateuser.executeUpdate();
    }

    @Override
    public User getUserById(int userId) throws SQLException {
        User user = null;
        String query = resourceBundle.getString("selectuserbyid");
        getuserbyid = conn.prepareStatement(query);
        getuserbyid.setInt(1,userId);
        resultSet=getuserbyid.executeQuery();
        while(resultSet.next()) {
            user = new User();
            user.setUserId(resultSet.getInt(1));
            user.setUserName(resultSet.getString(2));
            user.setEmail(resultSet.getString(3));
            user.setPassword(resultSet.getString(4));
            user.setSecQue(resultSet.getString(5));
            user.setAnswer(resultSet.getString(6));
            user.setAddress(resultSet.getString(7));
            user.setPhone(resultSet.getLong(8));
            if(resultSet.getInt(9)==1) {
                user.setUserMode(UserMode.ADMIN);
            } else {
                user.setUserMode(UserMode.CUSTOMER);
            }
            CartDao cartDao = new CartDaoImpl();
            user.setCart(cartDao.getCartByUser(user));
        }
        return user;
    }
}
