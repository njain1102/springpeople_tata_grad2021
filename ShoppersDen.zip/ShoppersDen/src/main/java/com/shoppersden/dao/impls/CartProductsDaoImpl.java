package com.shoppersden.dao.impls;

import com.shoppersden.dao.interfaces.CartProductsDao;
import com.shoppersden.dao.interfaces.ProductDao;
import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.CartProducts;
import com.shoppersden.models.Product;
import com.shoppersden.models.User;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CartProductsDaoImpl implements CartProductsDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private Statement statement;
    private PreparedStatement addproductincart,getallproductincart,emptyusercart;
    private ResultSet resultSet;

    public CartProductsDaoImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection not estd!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addProductInCart(User user, int productId, int quantity) throws SQLException {
        String productQuery=resourceBundle.getString("addproductincart");
        addproductincart=conn.prepareStatement(productQuery);
        addproductincart.setInt(1,user.getCart().getCartId());
        addproductincart.setInt(2,productId);
        addproductincart.setDate(3,Date.valueOf(LocalDate.now()));
        addproductincart.setInt(4,quantity);
        addproductincart.executeUpdate();
    }


    @Override
    public List<CartProducts> getAllProductInCart(User user) throws SQLException {
        List<CartProducts> cartProductsList=new ArrayList<CartProducts>();
        Product product=null;
        CartProducts cartProducts=null;
        ProductDao productDao=new ProductDaoImpl();
        String productQuery=resourceBundle.getString("selectproductincart");
        getallproductincart=conn.prepareStatement(productQuery);
        getallproductincart.setInt(1,user.getCart().getCartId());
        resultSet=getallproductincart.executeQuery();
        while (resultSet.next()) {
            product=productDao.getProductById(resultSet.getInt(2));
            cartProducts=new CartProducts();
            cartProducts.setCart(user.getCart());
            cartProducts.setProduct(product);
            cartProducts.setDateAdded(resultSet.getDate(3).toLocalDate());
            cartProducts.setQuantity(resultSet.getInt(4));
            cartProductsList.add(cartProducts);
        }
        return cartProductsList;
    }

    @Override
    public void emptyUserCart(User user) throws SQLException {
        String productQuery = resourceBundle.getString("emptycartproducts");
        emptyusercart=conn.prepareStatement(productQuery);
        emptyusercart.setInt(1,user.getCart().getCartId());
        emptyusercart.executeUpdate();
    }
}
