package com.shoppersden.dao.impls;

import com.shoppersden.dao.interfaces.CategoryDao;
import com.shoppersden.dao.interfaces.ProductDao;
import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.Category;
import com.shoppersden.models.Product;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ProductDaoImpl implements ProductDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private Statement statement;
    private PreparedStatement addproduct,getproductbyid,updateproductname;
    private ResultSet resultSet;

    public ProductDaoImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection not estd!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public List<Product> getAllProducts() throws SQLException {
        List<Product>productList=new ArrayList<Product>();
        Product product= null;
        String query = resourceBundle.getString("selectallproduct");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()) {
            product = new Product();
            product.setPid(resultSet.getInt(1));
            product.setPname(resultSet.getString(2));
            product.setDate(resultSet.getDate(3).toLocalDate());
            product.setPrice(resultSet.getInt(4));
            product.setQuantity(resultSet.getInt(5));
            product.setDescription(resultSet.getString(6));

            CategoryDao categoryDao = new CategoryDaoImpl();
            Category category=categoryDao.getCategoryById(resultSet.getInt(7));
            product.setCategory(category);

            productList.add(product);
        }
        return productList;
    }

    @Override
    public Product getProductById(int pid) throws SQLException {
        Product product = null;
        String query = resourceBundle.getString("selectproductbyid");
        getproductbyid = conn.prepareStatement(query);
        getproductbyid.setInt(1,pid);
        resultSet=getproductbyid.executeQuery();
        while(resultSet.next()) {
            product = new Product();
            product.setPid(resultSet.getInt(1));
            product.setPname(resultSet.getString(2));
            product.setDate(resultSet.getDate(3).toLocalDate());
            product.setPrice(resultSet.getInt(4));
            product.setQuantity(resultSet.getInt(5));
            product.setDescription(resultSet.getString(6));

            CategoryDao categoryDao = new CategoryDaoImpl();
            Category category=categoryDao.getCategoryById(resultSet.getInt(7));
            product.setCategory(category);
        }
        return product;
    }

    @Override
    public void addProduct(Product product) throws SQLException {
        String addProduct=resourceBundle.getString("addproduct");
        addproduct=conn.prepareStatement(addProduct);
        addproduct.setInt(1,product.getPid());
        addproduct.setString(2,product.getPname());
        addproduct.setDate(3, Date.valueOf(LocalDate.now()));
        addproduct.setLong(4,product.getPrice());
        addproduct.setInt(5,product.getQuantity());
        addproduct.setString(6,product.getDescription());
        addproduct.setInt(7,product.getCategory().getCid());
        addproduct.executeUpdate();
    }

    @Override
    public void updateProductName(int pid, String pname) throws SQLException {
        String query = resourceBundle.getString("updateproductname");
        updateproductname = conn.prepareStatement(query);
        updateproductname.setString(1,pname);
        updateproductname.setInt(2,pid);
        updateproductname.executeUpdate();
    }


}
