package com.shoppersden.utility;

import com.shoppersden.dao.impls.*;
import com.shoppersden.dao.interfaces.*;
import com.shoppersden.models.*;

import java.sql.SQLException;
import java.util.Scanner;

public class CustomerApp {
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws SQLException {
        UserDao userDao = new UserDaoImpl();
        LoginDao loginDao = new LoginDaoImpl();
        User user = null;
        System.out.print("Enter ID: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter Password: ");
        String pass = sc.nextLine();
        if (loginDao.passwordVerfication(id, pass)) {
            System.out.println("IN CUSTOMER MODE");
        } else {
            System.out.println("PLEASE REGISTER");
        }
    }
}
