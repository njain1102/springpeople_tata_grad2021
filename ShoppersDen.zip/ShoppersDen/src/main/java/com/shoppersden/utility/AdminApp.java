package com.shoppersden.utility;

import com.shoppersden.dao.impls.*;
import com.shoppersden.dao.interfaces.*;
import com.shoppersden.models.*;

import java.sql.SQLException;
import java.util.Scanner;

public class AdminApp {
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws SQLException {
        LoginDao loginDao = new LoginDaoImpl();
        UserDao userDao = new UserDaoImpl();
        CategoryDao categoryDao = new CategoryDaoImpl();
        User user = null;
        System.out.print("Enter ID: ");
        int id = Integer.parseInt(sc.nextLine());
        //sc.next();
        System.out.print("Enter Password: ");
        String pass = sc.nextLine();
        //sc.next();
        if (loginDao.adminVerfication(id)) {
            if (loginDao.passwordVerfication(id, pass)) {
                user = userDao.getUserById(id);
                System.out.println("IN ADMIN MODE");
                }
            else {
                System.out.println("INTRUDER");
                }
            }
        }
    }

