package com.shoppersden.models;

public enum PaymentMode {
    UPI,DEBIT
}
