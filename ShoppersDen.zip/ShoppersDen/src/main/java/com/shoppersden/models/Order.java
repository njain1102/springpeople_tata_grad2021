package com.shoppersden.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order {
    private int orderId;
    private LocalDate datePlaced;
    private Cart cart;
    private User user;
    private LocalDate dateDelivered;
    private int amount;
    private PaymentMode paymentMode;
    private boolean paid;
}
