package com.shoppersden.models;

public enum UserMode {
    ADMIN,CUSTOMER
}
