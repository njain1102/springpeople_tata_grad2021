package com.tata.Q1;
import java.util.Scanner;

public class Main {

    private static void menu(int n, float price){
        System.out.println(n + " ) Product "+ n + " - Price: Rs "+ price);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        float totalPrice= 0.0f;
        float [] prices = {22.5F,44.5F,9.98F};
        int flag = 1;
        System.out.println("\n\t\t\tMenu\n");
        for(int i=0;i<3;i++) {
            menu(i+1,prices[i]);
        }
        System.out.println("4 ) To end buying the products.");
        while(true)
        {
            System.out.print("Enter the Id to process further: ");
            int p_id = Integer.parseInt(sc.nextLine());
            //sc.nextLine();
            if(p_id==4)
                break;
            System.out.print("Enter the quantity to buy: ");
            int qty = Integer.parseInt(sc.nextLine());
            //sc.nextLine();
            switch(p_id) {
                case 1:
                    totalPrice += (float) qty * 22.5f;
                    break;
                case 2:
                    totalPrice += (float) qty * 44.5f;
                    break;
                case 3:
                    totalPrice += (float) qty * 9.98f;
                    break;
            }
        }
        System.out.println("\nThe total amount: " + totalPrice);
    }
    }

