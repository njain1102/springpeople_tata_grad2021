package com.tata.Q2;

import java.util.Scanner;

class worker{
    String name;
    int empNo;
    public worker(int no,String n){
        empNo=no;
        name=n;
    }

    void show(){
        System.out.println("\n");
        System.out.println("Employee number : "+empNo);
        System.out.println("Employee name : "+name);
    }
}
class dailyWorker extends worker{
    int rate;
    dailyWorker(int no,String n,int r){
        super(no,n);
        rate=r;
    }
    void pay(int h){
        show();
        System.out.println("Salary : "+rate*h);
    }
}
class salariedWorker extends worker{
    int rate;
    salariedWorker(int no,String n,int r)
    {
        super(no,n);
        rate=r;
    }
    int hour=40;
    void pay()
    {
        show();
        System.out.println("Salary : "+rate*hour);
    }
}
public class Main {
    public static void getDetails(int num){
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the Employee Number: ");
        int e = sc.nextInt();
        sc.nextLine();

        System.out.println("Enter the Employee Name: ");
        String n = sc.nextLine();

        System.out.println("Enter the Employee Salary rate:");
        int sr = sc.nextInt();
        sc.nextLine();

        if(num==0) {
            System.out.println("Enter the Employee Working hours:");
            int h = sc.nextInt();
            sc.nextLine();
            dailyWorker d=new dailyWorker(e,n,sr);
            d.pay(h);
        }
        else {
            salariedWorker s = new salariedWorker(e, n, sr);
            s.pay();
        }
    }
    public static void main(String[] args)
    {
        System.out.println("For a Daily worker");
        getDetails(0);
        System.out.println("\n\nFor a  Salaried worker");
        getDetails(1);

    }
}








