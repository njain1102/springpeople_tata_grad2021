package Assignment.Day1;

public class Worker {
    public String name;

//    public Worker(String name,int empNo)
//    {
//        this.name=name;
//        this.empNo=empNo;
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    void display()
    {
        System.out.println(this.name);
    }
}
