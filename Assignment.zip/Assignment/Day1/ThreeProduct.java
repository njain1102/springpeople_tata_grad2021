package Assignment.Day1;

import java.util.Scanner;

public class ThreeProduct {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double totalRetailPrice = 0;
        while (true) {
            System.out.println("1 - Product 1, 22.50");
            System.out.println("2 - Product 2, 44.50");
            System.out.println("3 - Product 3, 9.98");
            System.out.println("4 - Exit program");
            System.out.print("Enter product number: ");
            int productnumber = sc.nextInt();
            if (productnumber == 4) {
                break;
            }

            System.out.print("Enter quantity sold: ");
            int quantitySold = sc.nextInt();
            switch (productnumber) {
                case 1:
                    totalRetailPrice += 22.50 * quantitySold;
                    break;
                case 2:
                    totalRetailPrice += 44.50 * quantitySold;
                    break;
                case 3:
                    totalRetailPrice += 9.98 * quantitySold;
                    break;
                default:
                    totalRetailPrice += 0;
                    break;
            }
            System.out.println("\nThe total retail value of all products sold: " + totalRetailPrice);
        }
    }
}