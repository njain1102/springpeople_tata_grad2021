package Assignment.Day1;

import java.util.Random;
import java.util.Scanner;

public class WorkerMain {
    public static void main(String... args)
    {
        Scanner sc = new Scanner(System.in);
        //For DailyWorker

        DailyWorker dw=new DailyWorker();
        System.out.println("Enter the name of the DailyWorker: ");
        dw.setName(sc.next());
        dw.setSalaryrate(new Random().nextInt(1000));
        System.out.println("Enter the number of days: ");
        dw.Pay(sc.nextInt());


        //For SalariedWorker
        SalariedWorker sw = new SalariedWorker();
        System.out.println("Enter the name of the SalariedWorker: ");
        sw.setName(sc.next());
        sw.setSalaryRate(new Random().nextInt(1000));
        sw.Pay();
    }
}
