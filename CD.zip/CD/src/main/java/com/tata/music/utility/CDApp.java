package com.tata.music.utility;

import com.tata.music.Business.CDSorter;
//import com.tata.assignment.Business.Cdsorter;
import com.tata.music.Dao.CDDao;
import com.tata.music.Dao.CDImpl;
//import com.tata.assignment.Dao.CdDao;
//import com.tata.assignment.Dao.Cdimp;
import com.tata.music.models.CD;

import java.util.Collections;
import java.util.List;

public class CDApp {
    public static void main(String args[]){
        CDDao cdDao=new CDImpl();
        List<CD> cdd=cdDao.getAllCD();
        System.out.println("\nBefore Sorting the CD details");
        for(CD cd:cdd)
        {
            System.out.println(cd);
        }
        System.out.println("\nAfter Sorting the CD details");
        Collections.sort(cdd,new CDSorter());
        for(CD cd:cdd)
        {
            System.out.println(cd);
        }

    }
}
