package com.tata.music.Dao;

import com.tata.music.models.CD;

import java.util.List;

public interface CDDao {
    List<CD> getAllCD() ;
}
