package com.tata.music.Dao;
import com.tata.music.models.CD;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CDImpl implements CDDao {


    @Override
    public List<CD> getAllCD() {
        return getData();
    }



    private List<CD> getData(){
        Scanner sc=new Scanner(System.in);
        List<CD> getCd = new ArrayList<>();
        CD cdd = null;
        System.out.println("Enter the Number of CD details to sort");
        int n = sc.nextInt();
        sc.nextLine();
        for(int i=0;i<n;i++)
        {
            cdd=new CD();
            System.out.println("Enter Singer Name");
            cdd.setSinger(sc.nextLine());
            System.out.println("Enter the Title");
            cdd.setTitle(sc.nextLine());
            getCd.add(cdd);
        }
        return getCd;


    }

}
