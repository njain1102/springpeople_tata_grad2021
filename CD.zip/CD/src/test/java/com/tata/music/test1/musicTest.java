package com.tata.music.test1;

import com.tata.music.Business.CDSorter;
import com.tata.music.Dao.CDDao;
import com.tata.music.Dao.CDImpl;
import com.tata.music.models.CD;
import com.tata.music.utility.CDApp;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;
public class musicTest {


    private CD cd1,cd2,cd3,cd4;
    private CDSorter cds1,cds2;
    private CDDao cdDao1,cdDao2;
    private CDApp cdd1,cdd2;

    @BeforeEach
    public void getInstance(){
        cd1 =new CD();
        cd1.setTitle("Sheesha ho ya dil hi");
        cd1.setSinger("Lata Mangeshkar");
        cd2 =new CD("Kishore Kumar","Kabhi kabhie");
        //cd3 = new CD("Arijit Singh","Aashiqui");
        cd4 = new CD("Kishore Kumar","Kabhi kabhie");
        cds1=new CDSorter();
        cds2=new CDSorter();
        cdDao1 =new CDImpl();
        cdDao2=new CDImpl();
        cdd1=new CDApp();
        cdd2=new CDApp();
    }



    @Test
    @DisplayName("Title length greater than zero")
    public void  titleLengthGreaterThanZeroTest(){
        assertTrue(cd1.getTitle().length()>0);
    }


    @Test
    @DisplayName("Singer name should not be null")
    public void singerNameShouldNotBeNull()

    {
        assertThrows(NullPointerException.class,()->{cd3.getSinger();
        });

    }

    @ParameterizedTest
    @DisplayName("Valid title and Singer")
    @CsvFileSource(resources = "cdSongs.csv",numLinesToSkip =1)
    void csvSourceTest(String title,String singer){
        assertTrue(title.length()>0);
        assertTrue(singer.length()>0);

    }

    @Test
    @DisplayName("CD details not present for this object")
    public void titleNameShouldNotBeNull()
    {
        assertThrows(NullPointerException.class,()->{cd3.getTitle();
        });
    }

    @RepeatedTest(5)
    @DisplayName("Check the consistency of the function")
    void repeatedTestWithRepetitionInfo(RepetitionInfo repetitionInfo) {
        assertEquals(5, repetitionInfo.getTotalRepetitions());
        assertEquals(cds1.compare(cd1,cd2),cds2.compare(cd1,cd2));
    }

    @Test
    @DisplayName("Unique Title")
    public void uniqueTitleTest(){
        assertNotEquals(cd1.getTitle(),cd2.getTitle());
    }

    @Test
    @DisplayName("Unique Singer")
    public void uniqueSingerTest(){
        assertNotEquals(cd1.getSinger(),cd2.getSinger());
    }

}
